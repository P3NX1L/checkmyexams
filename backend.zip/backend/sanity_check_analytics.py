import os
from dotenv import load_dotenv, find_dotenv
from supabase import create_client
from app.analytics.service import (
    update_analytics,
    update_feedback_analytics
)

load_dotenv(find_dotenv())

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_API_KEY")
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

TABLE_NAME = "analytics"

TEST_USER_ID = "sanity_user"
TEST_STUDY_SPACE_ID = "sanity_space"
TEST_SUBJECT = "Physics"

# topic, marks_scored, marks_possible, weak_topic, comment
initial_entries = [
    ("Kinematics", 3, 3, False, "Excellent accuracy."),
    ("Kinematics", 2, 3, False, "Good but missed a detail."),
    ("Newton Laws", 1, 3, True, "Misunderstood equilibrium."),
    ("Newton Laws", 3, 3, False, "Great application of laws."),
    ("Kinematics", 1.5, 3, True, "Review vector decomposition.")
]

# extra entries to force summary recomputation once count >= 5
extra_entries_to_trigger_summary = [
    ("Kinematics", 2, 3, False, "Steady improvement."),
    ("Kinematics", 3, 3, False, "Strong attempt."),
    ("Kinematics", 2.5, 3, False, "Better clarity on concepts."),
]


def print_section(title: str):
    print("\n" + "-" * 80)
    print(title)
    print("-" * 80 + "\n")


print_section("Checking if analytics table exists")

try:
    supabase.table(TABLE_NAME).select("*").limit(1).execute()
    print("analytics table found")
except Exception as e:
    print("Could not access analytics table")
    print("Error:", e)
    exit(1)


print_section("Cleaning previous sanity test rows")

supabase.table(TABLE_NAME).delete() \
    .eq("user_id", TEST_USER_ID) \
    .eq("study_space_id", TEST_STUDY_SPACE_ID) \
    .eq("subject", TEST_SUBJECT) \
    .execute()

print("Cleanup complete")


print_section("Running initial analytics + feedback test")

for idx, (topic, scored, total, weak, comment) in enumerate(initial_entries, start=1):
    print(f"Entry {idx}: Topic={topic}, Score={scored}/{total}, Weak={weak}")

    analytics = update_analytics(
        user_id=TEST_USER_ID,
        study_space_id=TEST_STUDY_SPACE_ID,
        subject=TEST_SUBJECT,
        topic=topic,
        marks_scored=scored,
        marks_possible=total
    )

    print(f"  Subject Accuracy: {analytics['accuracy']:.2f}%")
    print(f"  Recent Accuracy: {analytics['recent_accuracy']:.2f}%")

    summary = update_feedback_analytics(
        user_id=TEST_USER_ID,
        study_space_id=TEST_STUDY_SPACE_ID,
        subject=TEST_SUBJECT,
        topic=topic,
        comment=comment,
        weak_topic=weak,
        marks_scored=scored,
        marks_possible=total
    )

    print(f"  Topic Summary Now: {summary}")

print_section("Adding extra entries to reach frequency threshold")

for idx, (topic, scored, total, weak, comment) in enumerate(extra_entries_to_trigger_summary, start=1):
    print(f"Extra Entry {idx}: Topic={topic}, Score={scored}/{total}, Weak={weak}")

    analytics = update_analytics(
        user_id=TEST_USER_ID,
        study_space_id=TEST_STUDY_SPACE_ID,
        subject=TEST_SUBJECT,
        topic=topic,
        marks_scored=scored,
        marks_possible=total
    )

    print(f"  Subject Accuracy: {analytics['accuracy']:.2f}%")

    summary = update_feedback_analytics(
        user_id=TEST_USER_ID,
        study_space_id=TEST_STUDY_SPACE_ID,
        subject=TEST_SUBJECT,
        topic=topic,
        comment=comment,
        weak_topic=weak,
        marks_scored=scored,
        marks_possible=total
    )

    print(f"  Topic Summary After Extra Entry: {summary}")

print_section("Fetching final aggregated analytics from Supabase")

resp = (
    supabase.table(TABLE_NAME)
    .select("*")
    .eq("user_id", TEST_USER_ID)
    .eq("study_space_id", TEST_STUDY_SPACE_ID)
    .eq("subject", TEST_SUBJECT)
    .execute()
)

if not resp.data:
    print("No analytics record found. Test failed.")
    exit(1)

record = resp.data[0]

print("User:", record["user_id"])
print("Study Space:", record["study_space_id"])
print("Subject:", record["subject"])

print_section("Subject-level Statistics")

print("Total Marks Scored:", record.get("total_marks_scored", 0))
print("Total Marks Possible:", record.get("total_marks_possible", 0))
print("Final Weighted Accuracy:", record.get("accuracy", 0))

print_section("Topic-level Stats (topics column)")

topics = record.get("topics", {})
for topic_name, stats in topics.items():
    print(f"Topic: {topic_name}")
    print("  Stats:", stats)

print_section("Per-topic Feedback History (feedback_history column)")

feedback_history = record.get("feedback_history", {})
for topic_name, history in feedback_history.items():
    print(f"Topic: {topic_name} - Entries: {len(history)}")
    for entry in history:
        print("   ", entry)

print_section("Per-topic Feedback Summary (feedback_summary column)")

feedback_summary = record.get("feedback_summary", {})
for topic_name, summary in feedback_summary.items():
    print(f"Topic: {topic_name}")
    print("  Summary:", summary)

print_section("Per-topic Feedback Counts (feedback_count column)")

feedback_count = record.get("feedback_count", {})
for topic_name, count in feedback_count.items():
    print(f"Topic: {topic_name} -> Count: {count}")

print_section("Progress History")

progress = record.get("progress_history", [])
print("Progress Entries:", len(progress))
for entry in progress:
    print(" ", entry)

print_section("Sanity Test Complete")
