# in the analytics feedback summary, it gets filled empty because we are updating the feedback summary every 5 times.
# test it with the live trigger
## if it works,,,,if not then keep printing the previous feedback summary till it gets updated. 
# or can change it to the analytics table to keep printing the previous data till updated.....LETS SEE...!
import time
import uuid
from datetime import datetime
from supabase import create_client
from dotenv import load_dotenv, find_dotenv
import os

from app.analytics.service import update_analytics, update_feedback_analytics


# Load .env
load_dotenv(find_dotenv())

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_API_KEY") or os.getenv("SUPABASE_KEY")
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)


def fetch_count(table: str):
    resp = supabase.table(table).select("id").execute()
    return len(resp.data)


def print_header(txt: str):
    print("\n" + "=" * 100)
    print(txt)
    print("=" * 80)


def scenario_basic_update():
    print_header("Scenario 1: Basic analytics update")

    user_id = "test_user_" + str(uuid.uuid4())
    study_space_id = "study_" + str(uuid.uuid4())
    subject = "Physics"

    print("User:", user_id)
    print("Study Space:", study_space_id)

    update_analytics(
        user_id=user_id,
        study_space_id=study_space_id,
        subject=subject,
        topic="Kinematics",
        marks_scored=3,
        marks_possible=5,
    )

    time.sleep(1)

    updated_count = fetch_count("analytics_history")
    topic_count = fetch_count("analytics_history_topics")
    progress_count = fetch_count("analytics_history_progress")

    print("analytics_history rows:", updated_count)
    print("analytics_history_topics rows:", topic_count)
    print("analytics_history_progress rows:", progress_count)

    assert updated_count >= 1
    assert topic_count >= 1
    assert progress_count >= 1

    print("Scenario 1 passed")


def scenario_multiple_updates():
    print_header("Scenario 2: Multiple updates and accuracy evolution")

    user_id = "test_user_" + str(uuid.uuid4())
    study_space_id = "study_" + str(uuid.uuid4())
    subject = "Maths"

    update_analytics(user_id, study_space_id, subject, "Algebra", 5, 5)
    time.sleep(0.5)
    update_analytics(user_id, study_space_id, subject, "Algebra", 4, 5)
    time.sleep(0.5)
    update_analytics(user_id, study_space_id, subject, "Calculus", 2, 5)
    time.sleep(1)

    hist_count = fetch_count("analytics_history")
    topics_count = fetch_count("analytics_history_topics")
    progress_count = fetch_count("analytics_history_progress")

    print("analytics_history rows:", hist_count)
    print("analytics_history_topics rows:", topics_count)
    print("analytics_history_progress rows:", progress_count)

    assert hist_count >= 3
    assert topics_count >= 3
    assert progress_count >= 3

    print("Scenario 2 passed")


def scenario_feedback_updates():
    print_header("Scenario 3: Feedback update and summary checks")

    user_id = "test_user_" + str(uuid.uuid4())
    study_space_id = "study_" + str(uuid.uuid4())
    subject = "Chemistry"

    update_analytics(user_id, study_space_id, subject, "Organic", 2, 3)
    time.sleep(1)

    update_feedback_analytics(
        user_id=user_id,
        study_space_id=study_space_id,
        subject=subject,
        topic="Organic",
        comment="Needs more practice on nomenclature",
        weak_topic=True,
        marks_scored=2,
        marks_possible=3,
    )

    time.sleep(1)

    feedback_count = fetch_count("analytics_history_feedback")
    summary_count = fetch_count("analytics_history_feedback_summary")

    print("analytics_history_feedback rows:", feedback_count)
    print("analytics_history_feedback_summary rows:", summary_count)

    assert feedback_count >= 1
    assert summary_count >= 1

    print("Scenario 3 passed")


def scenario_complex_mixed():
    print_header("Scenario 4: Complex mixed workflow")

    user_id = "test_user_" + str(uuid.uuid4())
    study_space_id = "study_" + str(uuid.uuid4())
    subject = "Biology"

    topics_attempted = [
        ("Genetics", 4, 5),
        ("Genetics", 3, 5),
        ("Botany", 5, 5),
        ("Botany", 4, 5),
        ("Zoology", 1, 5),
    ]

    for tpc, s, p in topics_attempted:
        update_analytics(user_id, study_space_id, subject, tpc, s, p)
        time.sleep(0.4)

    update_feedback_analytics(
        user_id=user_id,
        study_space_id=study_space_id,
        subject=subject,
        topic="Genetics",
        comment="Understanding improving but needs more clarity on Mendelian laws",
        weak_topic=False,
        marks_scored=4,
        marks_possible=5,
    )

    time.sleep(1)

    hist_count = fetch_count("analytics_history")
    topics_count = fetch_count("analytics_history_topics")
    progress_count = fetch_count("analytics_history_progress")
    feedback_count = fetch_count("analytics_history_feedback")
    summary_count = fetch_count("analytics_history_feedback_summary")

    print("analytics_history:", hist_count)
    print("analytics_history_topics:", topics_count)
    print("analytics_history_progress:", progress_count)
    print("analytics_history_feedback:", feedback_count)
    print("analytics_history_feedback_summary:", summary_count)

    assert hist_count >= 5
    assert topics_count >= 5
    assert progress_count >= 5
    assert feedback_count >= 1
    assert summary_count >= 1

    print("Scenario 4 passed")


def main():
    print_header("Starting Analytics History Sanity Test")

    scenario_basic_update()
    scenario_multiple_updates()
    scenario_feedback_updates()
    scenario_complex_mixed()

    print_header("All scenarios completed successfully")


if __name__ == "__main__":
    main()
