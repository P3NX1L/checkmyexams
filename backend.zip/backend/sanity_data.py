# sanity.py
import json
import os
from app.services.text_extraction import pdf_extraction
from app.services.data_cleaner import clean_text
from app.services import text_processing
from langchain.schema import Document

# ----------- CONFIG -------------
FILE_PATH = r"D:\testing_large.pdf"
# --------------------------------

def print_section(title):
    print("\n" + "="*40)
    print("🔍 " + title)
    print("="*40)

def sanity_check():
    print_section("1. Extract raw PDF pages")
    pages = pdf_extraction.extract_text_from_pdf(FILE_PATH)

    print(f"Total pages: {len(pages)}")

    raw_word_counts = []
    raw_text = ""

    for i, p in enumerate(pages, start=1):
        text = p.get("text", "") if isinstance(p, dict) else str(p)
        words = text.split()
        raw_word_counts.append(len(words))
        raw_text += " " + text
        print(f"Page {i} words: {len(words)}")

    print_section("2. Total RAW word count")
    total_raw_words = len(raw_text.split())
    print(f"RAW PDF words = {total_raw_words}")

    print_section("3. Clean text with data_cleaner.clean_text()")
    cleaned = clean_text(raw_text)
    cleaned_words = cleaned.split()
    print(f"Cleaned text word count = {len(cleaned_words)}")
    print("Sample cleaned text (first 500 chars):")
    print(cleaned[:500])

    print_section("4. Format with text_processing.text_formatter")
    formatted = text_processing.text_formatter(cleaned)
    formatted_words = formatted.split()
    print(f"Formatted text word count = {len(formatted_words)}")
    print("Sample formatted text (first 500 chars):")
    print(formatted[:500])

    print_section("5. Split into words using split_words")
    words = text_processing.split_words(formatted)
    print(f"split_words count = {len(words)}")

    print_section("6. Create chunks")
    chunks = text_processing.create_chunks(words, max_words=300, overlap=50)
    print(f"Number of chunks created = {len(chunks)}")

    for i, c in enumerate(chunks[:5]):
        print(f"Chunk {i} word count = {c['chunk_token_count']}")
        print("Chunk preview:", c["sentence_chunk"][:200])

    print_section("7. Convert chunks to Documents")
    docs = text_processing.chunks_to_documents(chunks, filename="sanity.pdf")
    print(f"Number of FINAL docs = {len(docs)}")

    print_section("8. Check doc metadata for forbidden values")
    for i, d in enumerate(docs[:10]):
        print(f"Doc {i} metadata = {d.metadata}")
        text_preview = d.page_content[:200]
        print(f"Doc {i} text preview = {text_preview}")

    print_section("9. Summary")
    print(json.dumps({
        "raw_words": total_raw_words,
        "cleaned_words": len(cleaned_words),
        "formatted_words": len(formatted_words),
        "final_words": len(words),
        "final_chunks": len(chunks),
        "final_docs": len(docs)
    }, indent=4))


if __name__ == "__main__":
    sanity_check()
