# ============================================================
# Sanity Test for Text Extraction + Cleaning + Global Chunking
# ============================================================

import os
from app.services.text_extraction import (
    pdf_extraction, docx_extraction, pptx_extraction,
    xlsx_extraction, md_extraction, txt_extraction
)
from app.services import data_cleaner
from app.services import text_processing

# Mapping extensions to specific extractors
extractors = {
    "pdf": pdf_extraction.extract_text_from_pdf,
    "docx": docx_extraction.extract_text_from_docx,
    "pptx": pptx_extraction.extract_text_from_pptx,
    "ppt": pptx_extraction.extract_text_from_pptx,
    "xlsx": xlsx_extraction.extract_text_from_xlsx,
    "md": md_extraction.extract_text_from_md,
    "txt": txt_extraction.extract_text_from_txt,
}

# Change this to your testing file or folder
INPUT_PATH = r"D:\testing_large.pdf"


def check_chunks(file_path):
    ext = file_path.split(".")[-1].lower()
    
    if ext not in extractors:
        print(f"Unsupported file type: {file_path}")
        return

    print(f"\nProcessing file: {file_path}")

    # Extract
    pages = extractors[ext](file_path)

    # Clean + Normalize pages
    page_objs = [
        {
            "text": text_processing.text_formatter(
                data_cleaner.clean_text(p.get("text", ""))
            )
        }
        for p in pages
        if p.get("text", "").strip()
    ]

    # Global sentence splitting
    #sentences = text_processing.split_sentences(page_objs)
    # Combine all cleaned page texts into a single string
    all_text = " ".join([p["text"] for p in page_objs])

    # Split into words
    words = text_processing.split_words(all_text)

    # Create chunks
    chunks = text_processing.create_chunks(
        words,
        max_words=300,
        overlap=50
    )


    # Validate chunks
    for idx, chunk in enumerate(chunks):
        wc = chunk["chunk_token_count"]
        status = "OK" if 280 <= wc <= 330 else "OUT_OF_RANGE"

        print(f"Chunk {idx+1}: {wc} words [{status}]")

    print(f"Total chunks created: {len(chunks)}\n")


def main():
    if os.path.isfile(INPUT_PATH):
        check_chunks(INPUT_PATH)

    elif os.path.isdir(INPUT_PATH):
        for fname in os.listdir(INPUT_PATH):
            if not fname.startswith("."):
                file_path = os.path.join(INPUT_PATH, fname)
                if os.path.isfile(file_path):
                    check_chunks(file_path)

    else:
        print("ERROR: Provided path is neither a valid file nor directory.")


if __name__ == "__main__":
    main()
