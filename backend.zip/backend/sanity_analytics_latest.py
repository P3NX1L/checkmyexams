import os
from dotenv import load_dotenv, find_dotenv
from supabase import create_client
from datetime import datetime
from app.analytics.service import (
    update_analytics,
    update_feedback_analytics
)

# Load env
load_dotenv(find_dotenv())
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_API_KEY")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

TABLE = "analytics"

TEST_USER = "sanity_user"
TEST_SPACE = "sanity_space"
SUBJECT = "Physics"

TOPIC_A = "Kinematics"        # 12 questions → feedback summary triggers twice (5 + 5)
TOPIC_B = "Newton Laws"       # 6 questions → triggers once (5)
TOPIC_C = "Friction"          # 3 questions → zero triggers
FREQ = 5                      # FEEDBACK_SUMMARY_FREQUENCY

# 12, 6, 3 test entries
topic_data = {
    TOPIC_A: 12,
    TOPIC_B: 6,
    TOPIC_C: 3,
}

def now():
    return datetime.now().strftime("%H:%M:%S")

def divider(text=""):
    print("\n" + "-" * 80)
    print(text)
    print("-" * 80)


# Remove old test record
divider("Cleaning Previous Test Data")
supabase.table(TABLE).delete().eq("user_id", TEST_USER).eq("study_space_id", TEST_SPACE).execute()
print("Cleanup complete")


# Build synthetic test dataset
def generate_entry(i):
    marks_scored = 3 if i % 2 == 0 else 2
    marks_possible = 3
    weak_topic = (i % 4 == 0)
    comment = f"Auto-generated feedback {i}"
    return marks_scored, marks_possible, weak_topic, comment


divider("Running full sanity test across 3 topics")

for topic, count in topic_data.items():
    print(f"\n\n=== Topic: {topic} | Total Attempts: {count} ===")

    for i in range(1, count + 1):
        marks_scored, marks_possible, weak, comment = generate_entry(i)

        print(f"\n[{now()}] Attempt {i}/{count}")
        print(f"Topic={topic}, Score={marks_scored}/{marks_possible}, Weak={weak}")

        # 1) Update analytics
        analytics = update_analytics(
            user_id=TEST_USER,
            study_space_id=TEST_SPACE,
            subject=SUBJECT,
            topic=topic,
            marks_scored=marks_scored,
            marks_possible=marks_possible,
        )

        print(f"   Subject Accuracy Updated → {analytics['accuracy']:.2f}%")

        # 2) Update feedback + summary
        summary = update_feedback_analytics(
            user_id=TEST_USER,
            study_space_id=TEST_SPACE,
            subject=SUBJECT,
            topic=topic,
            comment=comment,
            weak_topic=weak,
            marks_scored=marks_scored,
            marks_possible=marks_possible,
        )

        # Determine how many times summary has been triggered so far
        passes = (i // FREQ)

        if i % FREQ == 0:
            if passes == 1:
                print("   >>> FEEDBACK SUMMARY TRIGGERED (FIRST TIME)")
            elif passes == 2:
                print("   >>> FEEDBACK SUMMARY TRIGGERED (SECOND TIME)")
            else:
                print(f"   >>> FEEDBACK SUMMARY TRIGGERED (TIME #{passes})")

            print(f"      Strengths: {summary.get('strengths', [])}")
            print(f"      Needs Attention: {summary.get('needs_attention', [])}")

        else:
            print("   Feedback stored, summary not triggered yet.")


# Final Database Verification
divider("Final DB Record")

resp = (
    supabase.table(TABLE)
    .select("*")
    .eq("user_id", TEST_USER)
    .eq("study_space_id", TEST_SPACE)
    .eq("subject", SUBJECT)
    .execute()
)

if not resp.data:
    print("No analytics record found.")
else:
    record = resp.data[0]

    print("\nFinal Stored Analytics Record:")
    print("User:", record["user_id"])
    print("Study Space:", record["study_space_id"])
    print("Subject:", record["subject"])
    print("Total Marks Scored:", record.get("total_marks_scored"))
    print("Total Marks Possible:", record.get("total_marks_possible"))
    print("Final Weighted Accuracy:", record.get("accuracy"))
    print("\nTopic Stats:")
    for t, stats in record.get("topics", {}).items():
        print(f" - {t}: {stats}")

    print("\nFeedback Count (per topic):")
    print(record.get("feedback_count", {}))

    print("\nFeedback Summary (LLM generated):")
    print(record.get("feedback_summary", {}))

    print("\nFeedback History Lengths:")
    for t, h in record.get("feedback_history", {}).items():
        print(f" - {t}: {len(h)} entries")

divider("SANITY TEST COMPLETE")
