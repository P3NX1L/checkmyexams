from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import mathpix_trigger, rag_trigger, retrieval_trigger, create_questions_trigger,ask_ai_trigger
from app.routes import answer_check_trigger
from app.analytics.routes import router as analytics_router

app = FastAPI(title="CheckMyExams Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Triggers
app.include_router(mathpix_trigger.router, prefix="/syllabus", tags=["Topics Extraction from Syllabus"])
app.include_router(rag_trigger.router, prefix="/rag", tags=["RAG Pipeline"])
app.include_router(retrieval_trigger.router, prefix="/retrieval", tags=["retrieval pipeline"])
app.include_router(create_questions_trigger.router, prefix="/questions", tags=["generate questions trigger"])
app.include_router(answer_check_trigger.router, prefix="/answers", tags=["Answers checking trigger"])
app.include_router(ask_ai_trigger.router, prefix="/ai", tags=["Ask AI trigger"])
app.include_router(analytics_router)

@app.get("/")
async def root():
    return {"message": "Backend running", "routes": ["/topics", "/rag","/retrieval", "/questions","/answers","/ai"]}
